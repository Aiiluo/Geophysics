#!/bin/bash

gcc -o a.out Mkine2dvti.c -lm
./a.out 


